========================================

More information may be found at
 http://www.opengeospatial.org/standards/geosparql

The most current schema are available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------


2012-09-10  Simon Cox
  + v1.0: add geosparql 1.0.1 ontology sf/1.0/simple_features_geometries.rdf
            see OGC 11-052r4 at http://www.opengeospatial.org/standards/geosparql


-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2012 Open Geospatial Consortium.

-----------------------------------------------------------------------
