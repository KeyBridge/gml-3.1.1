OGC(r) Observation Extensions - ReadMe.txt
==========================================

The Observations and Measurements schema are defined in the OGC document
07-022r1.  The Observation Extensions are amended in the OGC change request
document 08-022r1.

More information on the OGC O&M standard may be found at
 http://www.opengeospatial.org/standards/om

The most current schema are available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------

2012-07-21  Kevin Stegemoller
   * See om/ReadMe.txt for additional detail

2008-02-18  Simon Cox
  * The Observation Extensions schema were moved from here to
    http://schemas.opengis.net/omx/1.0.0/ and also moved into a separate
    namespace http://www.opengis.net/omx/1.0

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2007-2008 Open Geospatial Consortium.

-----------------------------------------------------------------------
