OGC(r) GML 3.1.1 PIDF-LO Geometry Shape profile schema ReadMe.txt
======================================================

OGC(r) GML 3.1.1 PIDF-LO Geometry Shape profile Application Schema
-----------------------------------------------------------------------

More information may be found at
 http://www.opengeospatial.org/standards/gml

The most current schema is available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------

Change history:

2012-07-21  Kevin Stegemoller
  * v0.0.9-0.1.0: Copyright updated

2010-02-13  Kevin Stegemoller
  * v0.0.9-0.1.0: Update relative schema imports to absolute URLs (06-135r7 s#15)

2009-10-15  Kevin Stegemoller
  * v0.1.0: Add geoshape/0.1.0 Geodetic Shapes for PIDF-LO (OGC 06-142r1 BP)

2007-01-23  Kevin Stegemoller
  * v0.0.9: Add geoshape/0.0.9 Geodetic Shapes for PIDF-LO (OGC 06-142)

Note: check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2012 Open Geospatial Consortium.

-----------------------------------------------------------------------

