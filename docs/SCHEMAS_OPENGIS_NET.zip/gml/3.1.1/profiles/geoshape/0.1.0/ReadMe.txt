OpenGIS(r) GML PIDF-LO Geometry Shape Application Schema 0.1.0 (OGC 06-142r1) - ReadMe.txt
-----------------------------------------------------------------------

The GML PIDF-LO Geometry Shape Application Schema defined in the 
OGC document 06-142r1.

More information on the OGC GML standard may be found at
 http://www.opengeospatial.org/standards/gml


2009-10-15  Kevin Stegemoller

  * post geoshape/0.1.0 schemas from 06-142r1

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

The Open Geospatial Consortium, Inc. official schema repository is at
  http://schemas.opengis.net/ .

Copyright (c) 2007-2009 Open Geospatial Consortium.

