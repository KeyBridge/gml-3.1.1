2009-04-29  

  * Intelligence Community Intelligence Security Marking (IC ISM) Data Element
    Dictionary Version 2.1 (2008-08-19) posted

